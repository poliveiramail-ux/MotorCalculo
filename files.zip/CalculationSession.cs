using MotorCalculo.Engine.Evaluation;
using MotorCalculo.Engine.Models;
using MotorCalculo.Engine.Parsing;
using MotorCalculo.Engine.Sorting;

namespace MotorCalculo.Engine.Session;

/// <summary>
/// Orquestra um recálculo completo a partir de uma edição.
///
/// Fluxo:
///   1. Determina quais variáveis calculadas são afectadas (BFS no grafo inverso)
///   2. Selecciona a fórmula correcta para cada variável:
///      - Se o variableId editado é trigger de uma fórmula alternativa → usa essa alternativa
///      - Caso contrário → mantém a fórmula que estava activa (formula_id da célula existente)
///      - Fallback → 'main' ou 'default'
///   3. Avalia em ordem topológica, para cada período em ordem cronológica
///      (crucial para PREV — o período t lê o t-1 já calculado)
///   4. Devolve apenas as células que mudaram (delta)
///
/// Imutável em relação ao estado externo: trabalha numa cópia do dicionário de células.
/// </summary>
public sealed class CalculationSession
{
    private readonly IReadOnlyList<VariableDefinition>   _variables;
    private readonly IReadOnlyList<int>                  _periods;   // YYYYMM, ordem crescente
    private readonly ProjectStructure                    _project;

    // Pré-computados no constructor (custo único por sessão)
    private readonly IReadOnlyList<string>               _sortedCodes;   // ordem topológica
    private readonly Dictionary<string, VariableDefinition> _byCode;
    private readonly Dictionary<int, VariableDefinition>    _byId;
    private readonly Dictionary<string, int>                _codeToId;  // para o Evaluator
    private readonly Dictionary<string, HashSet<string>>    _reverseDeps; // code → dependentes

    public CalculationSession(
        IReadOnlyList<VariableDefinition> variables,
        IReadOnlyList<int> periods,
        ProjectStructure project)
    {
        _variables    = variables;
        _periods      = [.. periods.OrderBy(p => p)];   // garante ordem cronológica
        _project      = project;
        _sortedCodes  = TopologicalSort.Sort(variables);
        _byCode       = variables.ToDictionary(v => v.Code);
        _byId         = variables.ToDictionary(v => v.VariableId);
        _codeToId     = variables.ToDictionary(v => v.Code, v => v.VariableId);
        _reverseDeps  = BuildReverseDependencies();
    }

    /// <summary>
    /// Executa o recálculo a partir da célula editada.
    /// Não modifica <paramref name="cells"/> — trabalha numa cópia.
    /// </summary>
    /// <param name="editedKey">Célula que foi editada pelo utilizador ou importada.</param>
    /// <param name="cells">Estado completo das células antes da edição.</param>
    /// <returns>Lista de células que mudaram, em ordem de cálculo.</returns>
    public IReadOnlyList<CalculatedCell> Run(
        CellKey editedKey,
        Dictionary<CellKey, CellValue> cells)
    {
        if (!_byId.TryGetValue(editedKey.VariableId, out var editedVar))
            return [];

        // Cópia de trabalho — o motor não muta o input
        var working = new Dictionary<CellKey, CellValue>(cells);

        // Variáveis calculadas afectadas, na ordem topológica
        var affected    = GetAffectedVariableCodes(editedVar.Code);
        var toRecalc    = _sortedCodes
                              .Where(c => affected.Contains(c) && _byCode.TryGetValue(c, out var v) && !v.IsInput)
                              .Select(c => _byCode[c])
                              .ToList();

        var delta = new List<CalculatedCell>();
        var step  = 0;

        // Períodos em ordem cronológica (PREV correctamente resolvido)
        foreach (var period in _periods)
        {
            var year  = period / 100;
            var month = period % 100;

            foreach (var variable in toRecalc)
            {
                foreach (var (langId, lobId) in GetContexts(variable))
                {
                    var key = new CellKey(editedKey.VersionId, year, month,
                                          variable.VariableId, langId, lobId);

                    // Célula importada → motor não interfere
                    if (working.TryGetValue(key, out var existing) &&
                        existing.Source == CellSource.Imported)
                        continue;

                    var formula = SelectFormula(variable, key, working, editedKey.VariableId);
                    if (formula is null) continue;

                    // Parse + evaluate
                    AstNode ast;
                    try   { ast = new Parser(Tokenizer.Tokenize(formula.Expression)).Parse(); }
                    catch { continue; }

                    var ctx = new EvaluationContext(
                        editedKey.VersionId, year, month,
                        langId, lobId, _project, _codeToId, working);

                    var (value, status) = Evaluator.Evaluate(ast, ctx);

                    var newCell = new CellValue
                    {
                        Value     = status == CellStatus.Ok ? value : null,
                        Status    = status,
                        Source    = CellSource.Formula,
                        FormulaId = formula.FormulaId,
                    };

                    var before = working.GetValueOrDefault(key, CellValue.Empty());

                    // Só regista no delta se houve alteração
                    if (!CellsEqual(before, newCell))
                    {
                        working[key] = newCell;
                        delta.Add(new CalculatedCell(key, before, newCell, ++step, formula.Expression));
                    }
                }
            }
        }

        return delta;
    }

    // ── Formula selection ─────────────────────────────────────

    /// <summary>
    /// Selecciona a fórmula a usar para esta célula:
    /// 1. Se o variável editado é trigger de uma alternativa → usa essa alternativa
    /// 2. Caso contrário → mantém a fórmula anteriormente activa (via formula_id)
    /// 3. Fallback → 'main' ou 'default'
    /// </summary>
    private FormulaDefinition? SelectFormula(
        VariableDefinition variable,
        CellKey key,
        Dictionary<CellKey, CellValue> cells,
        int editedVariableId)
    {
        var formulas = variable.Formulas;
        if (formulas.Count == 0) return null;

        var alternatives = formulas.Where(f => f.FormulaType == "alternative").ToList();

        // Caso simples: só tem 'main', sem alternativas
        if (alternatives.Count == 0)
            return formulas.FirstOrDefault(f => f.FormulaType == "main");

        // Verifica se a variável editada activa uma alternativa
        var matchingAlt = alternatives
            .FirstOrDefault(f => f.TriggerVariableId == editedVariableId);

        if (matchingAlt is not null) return matchingAlt;

        // Mantém a fórmula anteriormente activa (persistida via formula_id)
        if (cells.TryGetValue(key, out var existing) && existing.FormulaId.HasValue)
        {
            var prev = formulas.FirstOrDefault(f => f.FormulaId == existing.FormulaId);
            if (prev is not null) return prev;
        }

        // Fallback: default
        return formulas.FirstOrDefault(f => f.FormulaType == "default");
    }

    // ── Dependency graph ──────────────────────────────────────

    /// <summary>BFS: encontra todos os códigos que dependem (directa ou transitivamente) de editedCode.</summary>
    private HashSet<string> GetAffectedVariableCodes(string editedCode)
    {
        var affected = new HashSet<string>();
        var queue    = new Queue<string>();

        if (_reverseDeps.TryGetValue(editedCode, out var direct))
            foreach (var d in direct) queue.Enqueue(d);

        while (queue.Count > 0)
        {
            var code = queue.Dequeue();
            if (!affected.Add(code)) continue;
            if (_reverseDeps.TryGetValue(code, out var more))
                foreach (var d in more) queue.Enqueue(d);
        }

        return affected;
    }

    /// <summary>
    /// Constrói o grafo de dependências inverso: code → set de variáveis que dependem deste code.
    /// Usa a união de todas as fórmulas (conservador — válido para qualquer trigger activo).
    /// </summary>
    private Dictionary<string, HashSet<string>> BuildReverseDependencies()
    {
        var reverse = _variables.ToDictionary(v => v.Code, _ => new HashSet<string>());

        foreach (var variable in _variables)
        {
            if (variable.IsInput || variable.Formulas.Count == 0) continue;

            foreach (var formula in variable.Formulas)
            {
                AstNode ast;
                try   { ast = new Parser(Tokenizer.Tokenize(formula.Expression)).Parse(); }
                catch { continue; }

                foreach (var dep in TopologicalSort.ExtractDependencies(ast))
                {
                    if (reverse.ContainsKey(dep))
                        reverse[dep].Add(variable.Code);
                }
            }
        }

        return reverse;
    }

    // ── Context enumeration ───────────────────────────────────

    /// <summary>Enumera todos os pares (langId, lobId) para o scope da variável.</summary>
    private IEnumerable<(int? LangId, int? LobId)> GetContexts(VariableDefinition variable) =>
        variable.ScopeCode switch
        {
            "template" => [(null, null)],
            "language" => _project.Languages.Select(l => ((int?)l.LanguageId, (int?)null)),
            "lob"      => _project.Languages
                              .SelectMany(l => l.Lobs
                                  .Select(b => ((int?)l.LanguageId, (int?)b.LobId))),
            _          => []
        };

    // ── Helpers ───────────────────────────────────────────────

    private static bool CellsEqual(CellValue a, CellValue b) =>
        a.Status == b.Status && a.Value == b.Value && a.FormulaId == b.FormulaId;
}
